// Get the button element
const button = document.getElementById('myButton');

// Add an event listener to the button
button.addEventListener('click', function() {
    // Change the button text when clicked
    button.textContent = 'Button clicked!';
});